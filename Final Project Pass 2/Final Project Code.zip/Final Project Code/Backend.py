#assume that flask module is downloaded
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/signup', methods=['POST'])
def signup():
    data = request.json
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')

    # Perform validation on received data
    if not username or not email or not password:
        return jsonify({'error': 'All fields are required'}), 400

    # Perform user registration logic (e.g., save to database)
    # Replace this with your actual logic
    # Example: 
    # User.objects.create(username=username, email=email, password=password)

    return jsonify({'message': 'User registered successfully'}), 201

if __name__ == '__main__':
    app.run(debug=True)
